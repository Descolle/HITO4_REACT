import Search from "./components/Search";

function App() {
  return (
    <>
      <h1>Buscador</h1>
      <Search />
    </>
  );
}

export default App;
