//Contenido.jsx
import { useEffect } from "react";

const Contenido = () => {
  useEffect(() => {
    console.log("Componente montado");
    return () => {
      console.log("Componente desmontado");
    };
  }, []);

  return <h1>Desde contenido</h1>;
};

export default Contenido;