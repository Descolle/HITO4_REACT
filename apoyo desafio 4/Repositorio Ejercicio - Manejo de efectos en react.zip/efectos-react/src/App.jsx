import { useState, useEffect } from "react";
import "./App.css";
import Contenido from "./Contenido";

function App() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  useEffect(() => {
    console.log("El email cambió su estado");
  }, [email]);

  return (
    <>
      <h1>Manejo de efectos en react</h1>
      <form>
        <input
          type="email"
          placeholder="nombre"
          name={email}
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          type="password"
          placeholder="password"
          name={password}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
      </form>

      {/* Componente cargado condiocionalmente si el password es igual a 123456 */}
      {password == "123456" && <Contenido />}
    </>
  );
}

export default App;
